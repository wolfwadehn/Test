﻿using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using static System.Console;
using static System.IO.Path;

namespace TestApp;

#region Class App ----------------------------------------------------------------------------------
/// <summary>This class contains application specific global constants and settings.</summary>
static class App {
   /// <summary>The application name (same as assembly name).</summary>
   public const string Name = "TestApp";

   /// <summary>The application build number</summary>
   public static int BuildNo => 1;

   public static ConsoleColor HighlightColor = 
      BackgroundColor == ConsoleColor.Black ? ConsoleColor.Yellow : ConsoleColor.DarkBlue;

   // Is this a developer machine?
   public static bool IsDeveloperMC () =>
#if DEBUG 
      true;
#else
      false;
#endif

   /// <summary>ProgramData directory.</summary>
   public static readonly DirectoryInfo Dir = Directory.CreateDirectory (Combine (Environment.GetEnvironmentVariable ("ProgramData")!, "Metamation", Name));
   /// <summary>Data directory to store caches etc..</summary>
   public static readonly DirectoryInfo DataDir = Dir.CreateSubdirectory ("Data");
   /// <summary>Settings directory.</summary>
   public static readonly DirectoryInfo SettingsDir = Dir.CreateSubdirectory ("Settings");
   /// <summary>Returns full-path to a data file.</summary>
   public static string GetDataFile (string name) => Combine (DataDir.FullName, name);
   /// <summary>Returns full-path to a setting file.</summary>
   public static string GetSettingsFile (string name) => Combine (SettingsDir.FullName, name);
}
#endregion

#region class AutoUpdate ---------------------------------------------------------------------------
static class AutoUpdate {
   #region Interfaces ------------------------------------------------
   /// <summary>Checks and applies the application update if available.</summary>
   /// Depending on the application mode and the arguments passed, this function 
   /// can perform following 2 tasks:
   /// 1. Check for the update and apply updated.
   /// 2. Publish the application to the target folder and update the update-registry.
   public static void Run () {
      var args = Environment.GetCommandLineArgs ();
      var appname = GetFileNameWithoutExtension (args.FirstOrDefault ());
      args = args.Skip (1).ToArray ();

      // Running in update mode. Apply the update and exit.
      if (appname.EqualsIC (GetFileNameWithoutExtension (Updater))) {
         ApplyUpdate (args);
         WriteLine ($"{App.Name} has been updated to build `{App.BuildNo}`. Press `Enter` and try again.");
         // Update applied. This process can exit now.
         Environment.Exit (0);
      }

      // Connect the the update registry.
      const string RegistryUrl = "https://xlate.azurewebsites.net/";
      // "https://localhost:7031/";
      using HttpClient registry = new () { BaseAddress = new Uri (RegistryUrl) };
      if (args.FirstOrDefault ().EqualsIC ("-publish")) {
         // Publish the application and exit.
         registry.Publish (args.Skip (1).ToArray ());
         Environment.Exit (0);
      }

      // Do not check for the update etc in the development mode.
      if (App.IsDeveloperMC ()) return;
      var settings = PublishSettings.Get ();
      // Set default update interval to 60 minutes.
      if (!int.TryParse ("" + settings.UpdateInterval, out var updateInterval)) updateInterval = 60;
      if (updateInterval < 0) return;

      var now = DateTime.Now;
      // Check and launch update if necessary.
      try {
         // Check if an update is due now.
         var nextUpdate = DateTime.FromFileTime (settings.LastUpdated).AddMinutes (updateInterval);
         if (updateInterval > 0 && nextUpdate > now) return;
         Write ("\n+ Checking for the new updates...");
         settings.LastUpdated = now.ToFileTime ();
         var (remotebuild, downloadurl) = registry.GetPublishedVersion ();
         if (remotebuild > App.BuildNo) {
            WriteLine ($"\nA new {App.Name} build `{remotebuild}` is available for the download. Running auto-update.");
            LaunchUpdate (downloadurl);
            settings.Save ();
            Environment.Exit (0);
         } else WriteLine ("Up-to-date.");
         settings.Save ();
      } catch (Exception ex) {
         Error ($"\n{ex.Message}");
      }
   }
   #endregion

   #region Implementation --------------------------------------------
   // Applies the update by terminating the original process which triggered
   // the update and copying over the updated exe to the given location.
   static void ApplyUpdate (string[] args) {
      if (args.Length < 2) {
         Write ("Usage: "); WriteLine ($"{Updater} <procid> <ExePath>");
         return;
      }
      int.TryParse (args[0], out var procid);
      var thisProc = Process.GetCurrentProcess ();
      var thisExe = "" + thisProc.MainModule?.FileName;

      Write ("\n+ Trying to terminate the existing process..");
      for (int i = 0; i < 10; i++) {
         Write (".");
         try {
            var process = Process.GetProcessById (procid);
            if (process == null || process.HasExited) break;
            process.Kill ();
            Thread.Sleep (100);
         } catch { }
      }
      WriteLine ();
      var strTarget = args[1];
      WriteLine ($"+ Updating {strTarget}...");
      File.Copy (thisExe, strTarget, true);
   }

   // Downloads the updated binary to the temp folder and launches it 
   // in the update mode.
   static void LaunchUpdate (string? downloadurl) {
      var thisProc = Process.GetCurrentProcess ();
      var thisExe = ChangeExtension ("" + thisProc.MainModule?.FileName, ".exe");
      if (downloadurl.IsBlank ()) {
         // Set OneDrive as the download url.
         downloadurl = DefaultDownloadUrl;
      }

      using var client = new HttpClient ();
      WriteLine ("+ Dowloading the update...");
      var resp = client.GetAsync (downloadurl).GetResult ();
      var data = resp.Content.ReadAsByteArrayAsync ().GetResult ();
      if (data == null) return;

      var updateDir = GetLocalFile ("Temp");
      Directory.CreateDirectory (updateDir);
      var updateApp = Combine (updateDir, Updater);
      if (updateApp.IsFile ()) try { File.Delete (updateApp); } catch { }
      File.WriteAllBytes (updateApp, data);

      // Compose the application arguments.
      WriteLine ("+ Launching the update process...");
      Exec (updateApp, $"{thisProc.Id} \"{thisExe}\"", false);
   }

   // Given the project file (CSProj), a local target directory and the direct download link, 
   // it first builds the project and publishes as a single exe file to the target directory
   // then updates the update-registry (an azure service) with the 'current' build number and
   // the download link to the exe file.
   // The publish details along with the service authorization credentials are saved to a 
   // settings file to make it easier to publish from the next time onwards.
   static bool Publish (this HttpClient client, string[] args) {
      static void Usage () {
         Write ("Usage: "); WriteLine ($"{LowerName} -publish <CSProjPath> <PublishDir> <DownloadUrl>");
         Write ("Ex: ");
         WriteLine ($"""{LowerName} -publish "W:\{App.Name}\Src\{App.Name}.csproj" "{DefaultPublishDir}" "{DefaultDownloadUrl}" """);
      }

      try {
         if (args.FirstOrDefault () == "?") {
            Usage ();
            return false;
         }
         PublishSettings settings = PublishSettings.Get ();
         string csproj = settings.ProjectPath;
         string publishTo = settings.PublishDir;
         if (args.Length > 0) csproj = GetFullPath (args[0]);

         if (args.Length > 1) {
            string strDir = GetFullPath (args[1]);
            if (!strDir.IsDir ()) {
               Error ($"Directory {strDir} doesn't exist");
               return false;
            }
            publishTo = strDir;
         }

         string downloadUrl = settings.DownloadUrl;
         if (args.Length > 2 && args[2].StartsWithIC ("http")) {
            downloadUrl = args[2];
         }

         if (!(csproj.IsFile () || publishTo.IsDir ())) {
            Usage ();
            return false;
         }

         if (!downloadUrl.IsBlank ()) settings.DownloadUrl = downloadUrl;
         else downloadUrl = DefaultDownloadUrl;

         WriteLine ($"\n{App.Name}.{App.BuildNo} will be compiled from: `{csproj}`\nAnd published to: `{publishTo}`");
         WriteLine ($"With downloaded URL: `{downloadUrl}`");
         WriteLine ("\nPress `Escape` to reject or press any other key to continue.");
         if (ReadKey ().Key == ConsoleKey.Escape) return false;
         
         WriteLine ("+ Signing into the publish registry...");
         client.SignIn ();

         // As 'this' application instance is already running. The exe is in readonly mode. Let 
         // use set the output to a temp dir for publishing.
         var tmpDir = GetLocalFile ("temp"); Directory.CreateDirectory (tmpDir);
         WriteLine ($"+ Publishing application to {publishTo}...");
         Exec ("dotnet.exe", @$"publish /p:PublishProfile=FolderProfile;assemblyName={App.Name};OutDir=""{tmpDir}"" -v 0 -c Release -o ""{publishTo}"" ""{csproj}""");

         // Published successfully. Remember stuff for the next command.
         settings.ProjectPath = csproj;
         settings.PublishDir = publishTo;

         Write ($"+ Updating application version {App.BuildNo}...");
         client.SetPublishedVersion (App.BuildNo, downloadUrl);
         WriteLine ("done.");
         settings.Save ();
         return true;
      } catch (Exception ex) {
         WriteLine ($"Error: {ex.Message}");
      }
      return false;
   }
   #endregion

   #region Registry APIs ---------------------------------------------
   static (int build, string? url) GetPublishedVersion (this HttpClient client) {
      var (version, s) = client.GetVar (AppVersionKey);
      if (version == null) return (0, s);
      return (version.GetValueOrDefault (), s);
   }

   static (int?, string?) GetVar (this HttpClient client, string varname) {
      var resp = client.Get ($"GetVar/{varname}");
      if (resp.StatusCode != HttpStatusCode.OK) return (null, null);
      Var? obj = resp.Content.ReadFromJsonAsync<Var?> ().GetResult ();
      if (obj == null) return (null, null);
      return (obj.IntVal, obj.StrVal);
   }

   static void SetPublishedVersion (this HttpClient client, int version, string strUrl)
      => client.SetVar (AppVersionKey, version, strUrl);

   static void SetVar (this HttpClient client, string varname, int? n, string? str) 
      => client.PostAsJsonAsync (client.Url ($"SetVar"), new Var (varname, n) { StrVal = str }).GetResult ();

   static void SignIn (this HttpClient client) {
      var settings = PublishSettings.Get ();
      string username = settings.UserName;
      string password = username.IsBlank () ? "" : settings.Password;
      bool savesettings = false;
      for (; ; ) {
         if (!username.IsBlank () && !password.IsBlank ()) {
            try {
               var authString = Convert.ToBase64String (Encoding.UTF8.GetBytes ($"{username}:{password}"));
               client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue ("Basic", authString);
               var res = client.Get ("SignIn");
               if (savesettings) {
                  settings.UserName = username;
                  settings.Password = password;
                  settings.Save ();
               }
               return;
            } catch (AuthorizationException) {
               Error ("Invalid credentials");
               username = ""; password = "";
            }
         }

         if (username.IsBlank () || password.IsBlank ()) {
            Write ("Username: ");
            username = ("" + ReadLine ()).Trim ();
            Write ("Password: ");
            password = ReadPassword ();
            WriteLine ();
            savesettings = true;
         }
      }

      static string ReadPassword () {
         var pass = string.Empty;
         ConsoleKey key;
         do {
            var keyInfo = ReadKey (intercept: true);
            key = keyInfo.Key;

            if (key == ConsoleKey.Backspace && pass.Length > 0) {
               Write ("\b \b");
               pass = pass[0..^1];
            } else if (!char.IsControl (keyInfo.KeyChar)) {
               Write ("*");
               pass += keyInfo.KeyChar;
            }
         } while (key != ConsoleKey.Enter);
         return pass.Encrypt ();
      }
   }

   static string Url (this HttpClient client, string target) {
      var strurl = client.BaseAddress?.OriginalString;
      return strurl.IsBlank ()
         ? throw new ApplicationException ("Empty or invalid service address")
         : $"{client.BaseAddress?.OriginalString.TrimEnd ('/')}/api/xlations/{target}";
   }
   #endregion

   #region Utilities and constants -----------------------------------
   const string AppVersionKey = $"{App.Name}AppVersion";
   const string DefaultPublishDir = @$"C:\Users\rajeshkumar\OneDrive - Trumpf Metamation Pvt Ltd\Apps\{App.Name}";
   const string DefaultDownloadUrl = @"https://indiametamationsoft-my.sharepoint.com/:u:/g/personal/rajesh_metamation_com/EXKAkf99ld1KlJz_XAfs6hsBj0U0raViIZnZjUVVD-Y_dA?download=1";
   readonly static string LowerName = App.Name.ToLower ();
   readonly static string Updater = $"update_{LowerName}.exe";

   /// <summary>Encrypts the given text and returns the cipher text. </summary>
   /// <param name="text">The text to be encrypted.</param>
   static string Encrypt (this string text) {
      if (text.IsBlank ()) return text;
      try {
         byte[] data = Encoding.UTF8.GetBytes (text);
         using var tdes = TripleDES.Create ();
         tdes.Key = ReadManifestData ("K.dat");
         tdes.Mode = CipherMode.ECB; tdes.Padding = PaddingMode.PKCS7;
         byte[] result = tdes.CreateEncryptor ().TransformFinalBlock (data, 0, data.Length);
         tdes.Clear ();
         return Convert.ToBase64String (result, 0, result.Length);
      } catch (Exception) {
         throw;
      }
   }

   // Prints an error message
   static void Error (string msg) {
      ForegroundColor = ConsoleColor.Red;
      WriteLine (msg);
      ResetColor ();
   }

   // Given the exe path and arguments, executes it and returns the error code.
   static int Exec (string exe, string args, bool wait = true) {
      ProcessStartInfo startinfo = new () {
         CreateNoWindow = false, UseShellExecute = false, Arguments = args,
         WorkingDirectory = Directory.GetCurrentDirectory (), FileName = exe
      };
      var proc = Process.Start (startinfo) ?? throw new TestAppException ($"Unable to execute '{exe}'");
      if (!wait) return 0;
      proc.WaitForExit ();
      var nExit = proc.ExitCode;
      proc.Close ();
      return nExit;
   }

   /// <summary>Returns an absolute filename, given a filename relative to this application.</summary>
   /// This does not check if the file or path you specify here exists. It just computes the
   /// filename and returns it. 
   static string GetLocalFile (string file) {
      if (sCodeBase == null) {
         var process = "" + Process.GetCurrentProcess ().MainModule?.FileName;
         sCodeBase = GetDirectoryName (process);
      }
      if (sCodeBase.IsBlank ()) {
         // Return the current working directory.
         sCodeBase = Environment.CurrentDirectory;
      }
      return GetFullPath (Combine (sCodeBase, file));
   }
   static string? sCodeBase = null;

   // Send a request and return the response message.
   static HttpResponseMessage Get (this HttpClient client, string url) {
      var resp = client.GetAsync (client.Url (url)).GetResult ();
      if (resp.StatusCode == HttpStatusCode.Unauthorized) throw new AuthorizationException ();
      return resp;
   }

   // Runs a task synchronously and returns the result.
   static T GetResult<T> (this Task<T> task) => task.GetAwaiter ().GetResult ();

   /// <summary>Reads the contents of a manifest stream as raw bytes</summary>
   static byte[] ReadManifestData (string name) {
      using var stm = GetResStream (name);
      byte[] data = new byte[stm!.Length];
      stm.Read (data, 0, data.Length);
      return data;
   }

   static Stream? GetResStream (string name) {
      var asm = Assembly.GetExecutingAssembly ();
      return asm.GetManifestResourceStream ($"{LowerName}.Res.{name}") ?? asm.GetManifestResourceStream ($"{App.Name}.Res.{name}");
   }

   /// <summary>Serializes an object to the raw bytes array.</summary>
   /// <typeparam name="T">The object type.</typeparam>
   /// <param name="obj">The object reference.</param>
   /// <returns>The serialized raw bytes.</returns>
   static byte[] Serialize<T> (this T obj) {
      using var ms = new MemoryStream ();
      JsonSerializer.Serialize (ms, obj);
      return ms.ToArray ();
   }

   /// <summary>Reads the object from its raw bytes.</summary>
   /// <typeparam name="T">The object type.</typeparam>
   /// <param name="data">Raw data.</param>
   /// <returns>The read object.</returns>
   static T? Deserialize<T> (this byte[] data) {
      using var ms = new MemoryStream (data);
      return JsonSerializer.Deserialize<T> (ms);
   }
   #endregion

   #region class PublishSettings -------------------------------------
   class PublishSettings {
      public string ProjectPath { get; set; } = "";
      public string PublishDir { get; set; } = "";
      public string DownloadUrl { get; set; } = "";
      public string UserName { get; set; } = "";
      public string Password { get; set; } = "";
      // The update interval in minutes .
      public string UpdateInterval { get; set; } = "";
      // Last update timestamp (filetime)
      public long LastUpdated { get; set; } = 0;

      public void Save () {
         string? dir = GetDirectoryName (SettingsFile);
         if (dir == null) return;
         Directory.CreateDirectory (dir);
         File.WriteAllBytes (SettingsFile, this.Serialize ());
      }

      public static PublishSettings Get () {
         if (It != null) return It;
         if (SettingsFile.IsFile ()) {
            try { It = File.ReadAllBytes (SettingsFile).Deserialize<PublishSettings> (); } catch { }
         }
         return It ??= new PublishSettings ();
      }
      static PublishSettings? It = null;

      readonly static string SettingsFile = App.GetSettingsFile ("publish.json");
   }
   #endregion

   #region class Var -------------------------------------------------
   public class Var {
      #region Constructors -------------------------------------------
      // Default constructor used by the EF serializer and json serializer.
      // Note: Do not make it private. Json cannot access private constructor.
      public Var () { Name = null!; }

      public Var (string key, int? value) {
         Name = key; IntVal = value;
      }

      public Var (string key, string? value) {
         Name = key; StrVal = value;
      }
      #endregion

      public string Name { get; set; }
      public int? IntVal { get; set; }
      public string? StrVal { get; set; }
   }
   #endregion

}
#endregion

#region Exceptions ---------------------------------------------------------------------------------
class TestAppException : ApplicationException { 
   public TestAppException (string message) : base (message) { }
}

class HttpException : TestAppException {
   public HttpException (HttpStatusCode status) : base (UnCamel (status.ToString ())) => Status = status;

   readonly public HttpStatusCode Status;

   /// <summary>Takes a CamelCase string and splits it to words "Camel Case" (inserting a space before each capital letter)</summary>
   static string UnCamel (string s) {
      var sb = new StringBuilder ();
      for (int i = 0; i < s.Length; i++) {
         char ch = s[i];
         if (i == 0) { sb.Append (ch); continue; }
         if (char.IsUpper (ch)) {
            // If this is an upper-case character, insert a space before this
            // (if the previous one is not an upper-case character)
            // (or if the next one is a lower case character)
            bool iInsert = !char.IsUpper (s[i - 1]);
            if (i < s.Length - 1 && !char.IsUpper (s[i + 1])) iInsert = true;
            if (iInsert) sb.Append (' ');
         }
         sb.Append (ch);
      }
      return sb.ToString ();
   }
}

class AuthorizationException : HttpException {
   public AuthorizationException () : base (HttpStatusCode.Unauthorized) { }
}
#endregion

#region Extenstion methods -------------------------------------
static class Extensions {
   /// <summary>Returns true if two strings are equal without case-sensitivity</summary>
   public static bool EqualsIC (this string? s, string other)
      => s != null && s.Equals (other, StringComparison.OrdinalIgnoreCase);

   /// <summary>Returns true if the specified string is null or whitespace</summary>
   public static bool IsBlank ([NotNullWhen (false)] this string? s)
      => string.IsNullOrWhiteSpace (s);

   /// <summary>Checks if the path is a valid directory.</summary>
   public static bool IsDir (this string path) {
      if (string.IsNullOrEmpty (path)) return false;
      return Directory.Exists (path);
   }

   /// <summary>Checks if the path is a valid file.</summary>
   public static bool IsFile (this string path) {
      if (string.IsNullOrEmpty (path)) return false;
      return File.Exists (path);
   }

   /// <summary>A case agnostic version of the String.StartsWith function</summary>
   public static bool StartsWithIC (this string s, string sub) => s.StartsWith (sub, StringComparison.OrdinalIgnoreCase);
}
#endregion