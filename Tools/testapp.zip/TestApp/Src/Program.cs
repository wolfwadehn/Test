﻿using TestApp;

AutoUpdate.Run ();
// See https://aka.ms/new-console-template for more information
Console.WriteLine ($"TestApp. Build {App.BuildNo}.");
